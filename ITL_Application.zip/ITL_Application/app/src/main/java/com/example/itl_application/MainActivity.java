package com.example.itl_application;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    private ActionBar toolbar;

    //public BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        toolbar = getSupportActionBar();
       // toolbar.setTitle("APP");

        FrameLayout frameLayout = findViewById(R.id.frmlyout);
        BottomNavigationView bottomNavigationView=findViewById(R.id.nav_view);
        loadFragment(new BlankFragment());

       bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
           @Override

           public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
               Fragment fragment=null;
               switch (menuItem.getItemId())
               {
                   case R.id.home:

                       fragment=new BlankFragment();

                       break;
                   case R.id.activity:
                      fragment=new ActivityFragment();
                   //   Toast.makeText(getApplicationContext(),"home",Toast.LENGTH_LONG).show();
                      break;
                   case R.id.profile:
                      fragment=new ProfileFragment();
                       break;
                       default:
                           return false;
               }
               return loadFragment(fragment);

           }
       });
    }
    private boolean loadFragment(Fragment fragment) {
        //switching fragment
        if (fragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.frmlyout, fragment)
                    .commit();
            return true;
        }
        return false;
    }
    }

