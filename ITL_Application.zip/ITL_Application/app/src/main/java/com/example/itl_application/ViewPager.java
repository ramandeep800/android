package com.example.itl_application;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;

//public class ViewPager  extends FragmentPagerAdapter {
//    private ArrayList<Fragment>fragments;
//    private ArrayList<String>titles;
////    public ViewPager(@NonNull FragmentManager fm) {
////        //super();
////        fragments=new ArrayList<>();
////        titles=new ArrayList<>();
////       // super(fm);
////    }
//
//    @NonNull
//    @Override
//    public Fragment getItem(int position) {
//        return fragments.get(position);
//    }
//
//    @Override
//    public int getCount() {
//        return fragments.size();
//    }
//}
