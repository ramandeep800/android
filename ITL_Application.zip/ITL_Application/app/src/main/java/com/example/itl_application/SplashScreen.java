package com.example.itl_application;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class SplashScreen extends AppCompatActivity {
    ImageView img,img2;
    Animation topanim,bottomanim;
    TextView txt1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash_screen);
        img=findViewById(R.id.logo);
        txt1=findViewById(R.id.itl);
        //img2=findViewById(R.id.logo1);
        topanim=AnimationUtils.loadAnimation(this, R.anim.top_animation);
        bottomanim=AnimationUtils.loadAnimation(this, R.anim.botton_animation);
        img.startAnimation(topanim);
        txt1.startAnimation(bottomanim);

        // img.animate().alpha(0f).setDuration(3000);
        //img2.animate().alpha(1f).setDuration(3000);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent= new Intent(SplashScreen.this, SignIn.class);

                startActivity(intent);


                finish();

            }
        },4000);

       // Animation animation = AnimationUtils.loadAnimation(this, R.anim.fade_in);
        //img.startAnimation(animation);
    }
}
