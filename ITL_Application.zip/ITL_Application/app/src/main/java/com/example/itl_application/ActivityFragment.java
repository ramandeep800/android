package com.example.itl_application;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;


public class ActivityFragment extends Fragment {
    int size=150;
    int rows=2;
    int columns=5;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v=inflater.inflate(R.layout.fragment_activity,null);
        CardView cardView=v.findViewById(R.id.cardview);
        GridLayout gridLayout=new GridLayout(getContext());
        gridLayout.setRowCount(rows);
        gridLayout.setColumnCount(columns);
        GridLayout.LayoutParams layoutParams=new GridLayout.LayoutParams();
        layoutParams.setMargins(size*30/100,size*30/100,size*30/100,size*30/100);
        gridLayout.setLayoutParams(layoutParams);
        return v;
    }
}