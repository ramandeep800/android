package com.example.itl_application;

import android.graphics.drawable.Drawable;

public class MyData extends DummyData {
public String Qus;
public String date;
public String Description;
public MyData(String qus,String date,String Description)
{
    this.Qus=qus;
    this.date=date;
    this.Description=Description;
}

    public String getQus() {
        return Qus;
    }

    public void setQus(String qus) {
        Qus = qus;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }
}