package com.example.itl_application;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdapterCardView extends RecyclerView.Adapter<AdapterCardView.MyViewHolder> {
    private ArrayList<MyData> myData;
    public AdapterCardView(ArrayList<MyData> data)
    {
        this.myData=data;
    }
    @Override
    public AdapterCardView.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_view, parent, false);
       // view.setOnClickListener(HomePage.myOnClickListener);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterCardView.MyViewHolder holder, int position) {
        MyData data=myData.get(position);
        holder.Qus.setText(data.getQus());
        holder.date.setText(data.getDate());
        holder.description.setText(data.getDescription());


    }

    @Override
    public int getItemCount() {
        return myData.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView Qus;
        TextView date;
       TextView description;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            this.Qus=(TextView)itemView.findViewById(R.id.textView2);
           this.date=(TextView)itemView.findViewById(R.id.textView3);
            this.description=(TextView)itemView.findViewById(R.id.textView6);
        }
    }
}
