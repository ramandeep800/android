package com.example.itl_application;

import com.example.itl_application.R;

public class DummyData {
    static String[] Titlearray = {"Cupcake", "Donut", "Eclair", "Froyo", "Gingerbread", "Honeycomb", "Ice Cream Sandwich","JellyBean", "Kitkat", "Lollipop", "Marshmallow"};
    static String[] Authorname={"Cupcake", "Donut", "Eclair", "Froyo", "Gingerbread", "Honeycomb", "Ice Cream Sandwich","JellyBean", "Kitkat", "Lollipop", "Marshmallow"};
    static String[] imagearray={"R.drawable.logotrnsprnt","R.drawable.logotrnsprnt","R.drawable.logotrnsprnt",
            "R.drawable.logotrnsprnt","R.drawable.logotrnsprnt","R.drawable.logotrnsprnt","R.drawable.logotrnsprnt", "R.drawable.logotrnsprnt",
            "R.drawable.logotrnsprnt","R.drawable.logotrnsprnt","R.drawable.logotrnsprnt"};
}
